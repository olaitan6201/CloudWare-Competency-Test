<?php
    session_start();
    
    include 'dbcon.php';
    include 'pdo.php';
    // include 'scripts.php';

    global $pdo;

    $script  = new Scripts($pdo);
?>