<?php
    if(isset($_POST['page'])){

        include '../init.php';

        if($_POST['page'] == 'users')
        {
            if($_POST['action'] == 'login')
            {

                $username = $script->clean_data($_POST['username']);
                $password = $script->clean_data($_POST['password']);

                $script->data = array(
                    ':user' =>  $username
                );

                $script->query ="
                SELECT * from users 
                where username = :user
                ";

                if($script->rowCount() > 0){
                    $users = $script->fetchAll();

                    foreach($users as $user){
                        if(!password_verify($password, $user->password)){
                            $output = array(
                                'error' =>  'Incorrect Password Input'
                            );
                        }else{
                            $_SESSION['test_user_id'] = $user->id;

                            $output = array(
                                'success'   =>  true
                            );
                        }
                    }
                }else{
                    $output = array(
                        'error' =>  'Username not found'
                    );
                }
                
                echo json_encode($output);
            }
        }
    }
?>