<?php
    if(isset($_POST['page'])){

        include '../init.php';

        if($_POST['page'] == 'users')
        {
            if($_POST['action'] == 'register')
            {

                $script->data = array(
                    ':name' =>  $script->clean_data($_POST['name']),
                    ':username' =>  $script->clean_data($_POST['username']),
                    ':email' =>  $script->clean_data($_POST['email']),
                    ':phone' =>  $script->clean_data($_POST['phone']),
                    ':password' =>  password_hash($_POST['password'], PASSWORD_DEFAULT)
                );

                $script->query = "
                INSERT into users 
                (name, username, email, phone, password) 
                values 
                (:name, :username, :email, :phone, :password) 
                ";

                $script->execute_query();

                $output = array(
                    'success'   =>  true
                );
        
                echo json_encode($output);
            }
        }
    }
?>