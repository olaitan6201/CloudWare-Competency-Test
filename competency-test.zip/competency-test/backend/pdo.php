<?php 


class Scripts {
    //protected $pdo;

    var $query;
	var $data;
	var $statement;
	var $filedata;

    function __construct($pdo){
        $this->pdo = $pdo;
    }


    public function checkInput($var){
        $var = htmlspecialchars($var);
        $var = trim($var);
        $var = stripcslashes($var);
        return $var;
    }


    public function execute_query()
	{
		$this->statement = $this->pdo->prepare($this->query);
		$this->statement->execute($this->data);
	}

	public function rowCount()
	{
		$this->execute_query();
		return $this->statement->rowCount();
	}


	public function redirect($page)
	{
		header('location:'.$page);
		exit;
	}


	public function fetchAll()
	{
		$this->execute_query();
		return $this->statement->fetchAll(PDO::FETCH_OBJ);
	}

	public function fetch()
	{
		$this->execute_query();
		return $this->statement->fetch(PDO::FETCH_OBJ);
	}

	public function clean_data($data)
	{
	 	$data = trim($data);
	  	$data = stripslashes($data);
	  	$data = htmlspecialchars($data);
	  	return $data;
	}

	public function Upload_file($path)
	{
		if(!empty($this->filedata['name']))
		{
			$extension = pathinfo($this->filedata['name'], PATHINFO_EXTENSION);

			$new_name = uniqid() . '.' . $extension;

			$_source_path = $this->filedata['tmp_name'];

			$target_path = $path . $new_name;

			move_uploaded_file($_source_path, $target_path);

			return $new_name;
		}else{
			return '';
		}
	}


}