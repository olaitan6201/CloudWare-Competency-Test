<?php

class Inventory
{
	var $host;
	var $username;
	var $password;
	var $database;
	var $connect;
	var $query;
	var $data;
	var $statement;
	var $filedata;
	var $branch_id;
	var $acct_id;

	function __construct()
	{
		$this->host = 'localhost';
		$this->username = 'root';
		$this->password = '';
		//$this->password = 'FuTa@(2017)';
		$this->database = 'deshalom';

		$this->connect = new PDO("mysql:host=$this->host; dbname=$this->database", "$this->username", "$this->password");

		@session_start();

		date_default_timezone_set('Africa/Lagos');

		if(isset($_SESSION['acct_id']) and !empty($_SESSION['acct_id']) and isset($_SESSION['branch'])){
			$this->branch_id = $_SESSION['branch'];
			$this->acct_id = $_SESSION['acct_id'];
		}
		elseif(isset($_SESSION['super_admin_id']) and !empty($_SESSION['super_admin_id']) and isset($_SESSION['branch'])){
			$this->branch_id = $_SESSION['branch'];
			$this->acct_id = $_SESSION['super_admin_id'];
		}
	}

	function execute_query()
	{
		$this->statement = $this->connect->prepare($this->query);
		$this->statement->execute($this->data);
	}

	function total_row()
	{
		$this->execute_query();
		return $this->statement->rowCount();
	}


	function redirect($page)
	{
		header('location:'.$page);
		exit;
	}


	function query_result()
	{
		$this->execute_query();
		return $this->statement->fetchAll();
	}

	function clean_data($data)
	{
	 	$data = trim($data);
	  	$data = stripslashes($data);
	  	$data = htmlspecialchars($data);
	  	return $data;
	}

	function execute_query_with_last_id()
	{
		$this->statement = $this->connect->prepare($this->query);

		$this->statement->execute($this->data);

		// $this->execute_query();

		return $this->connect->lastInsertId();
	}

	function Upload_file()
	{
		if(!empty($this->filedata['name']))
		{
			$extension = pathinfo($this->filedata['name'], PATHINFO_EXTENSION);

			$new_name = uniqid() . '.' . $extension;

			$_source_path = $this->filedata['tmp_name'];

			$target_path = 'uploads/' . $new_name;

			move_uploaded_file($_source_path, $target_path);

			return $new_name;
		}else{
			return '';
		}
	}

	function accountant_session_private()
	{
		if((!isset($_SESSION['acct_id']) or empty($_SESSION['acct_id'])) and !isset($_SESSION['branch']) and (!isset($_SESSION['super_admin_id']) or empty($_SESSION['super_admin_id'])))
		{
			$this->redirect('../pages/home.php');
		}
	}

	function accountant_session_public()
	{
		if(isset($_SESSION['acct_id']) and !empty($_SESSION['acct_id']) and isset($_SESSION['branch']))
		{
			$this->redirect('index.php');
		}
	}




	////////////////////OPTION FETCHS SECTION///////////////////

	function fetch_staffs()
	{
		$this->query = "SELECT id,sname,fname,oname from staffs";
		$output = '<option value="0" selected="selected"></option>';
		foreach($this->query_result() as $staff){
			$staffname = $staff['sname'].' '.$staff['fname'].' '.$staff['oname'];
			$staffid = $staff['id'];
			$output.='<option value="'.$staffid.'">'.$staffname.'</option>';
		}
		return $output;
	}

	function fetch_months(){
		return '<option>January</option> <option>February</option> <option>March</option> <option>April</option> <option>May</option> <option>June</option> <option>July</option> <option>August</option> <option>September</option> <option>October</option> <option>November</option> <option>December</option>';
	}

	function fetch_years(){
		$cur_year = date('Y');
		$output = '';
		for ($i=0; $i <= 10; $i++) { 
			$output.='<option>'.($cur_year - $i).'</option>';
		}

		return $output;
	}



	





	////////STAFFS SECTION ///////////////////
	function fetch_all_staffs(){
		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT * from staffs 
		where 
		branch_id = :branch_id 
		order by id desc 
		limit 20
		";

		$output = '';

		$i = 1;

		foreach($this->query_result() as $staff){
			$staffname = $staff["sname"]." ".$staff["fname"]." ".$staff["oname"];
			$output.='
				<tr>
					<td>'.$i.'</td>
					<td><img src="uploads/'.$staff["picture"].'" alt="'.$staffname.'" style="width: 50px; height:50px;"/></td>
					<td>'.$staffname.'</td>
					<td>'.$staff["email"].'</td>
					<td>'.$staff["tel"].'</td>
					<td>
						<a href="?page=edit_staff&staffid='.$staff["id"].'" class="btn btn-success btn-xs"><i class = "fa fa-pencil"></i> Edit</a>
					</td>
				</tr>
			';
			$i++;
		}
		return $output;
	}




	function fetch_req_staff($id){
		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT * from staffs 
		where 
		branch_id = :branch_id and (
		sname LIKE '%".$id."%' or 
		fname LIKE '%".$id."%' or 
		oname LIKE '%".$id."%' or 
		dob LIKE '%".$id."%' or 
		tel LIKE '%".$id."%' or 
		email LIKE '%".$id."%')
		";

		$output = '';

		$i = 1;

		foreach($this->query_result() as $staff){
			$staffname = $staff["sname"]." ".$staff["fname"]." ".$staff["oname"];
			$output.='
				<tr>
					<td>'.$i.'</td>
					<td><img src="uploads/'.$staff["picture"].'" alt="'.$staffname.'" style="width: 50px; height:50px;"/></td>
					<td>'.$staffname.'</td>
					<td>'.$staff["email"].'</td>
					<td>'.$staff["tel"].'</td>
					<td>
						<a href="?page=edit_staff&staffid='.$staff["id"].'" class="btn btn-success btn-xs"><i class = "fa fa-pencil"></i> Edit</a>
					</td>
				</tr>
			';
			$i++;
		}
		return $output;
	}





	//////////////SALARY SECTION/////////////////////
	function load_salary_table()
	{
		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT * from salary 
		inner join staffs 
		on `salary`.`staff_id` = `staffs`.`id` 
		where 
		salary.branch_id = :branch_id 
		order by salary.id desc 
		limit 10
		";

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $salary)
			{
				$staffname = $salary["sname"]." ".$salary["fname"]." ".$salary["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$salary["picture"].'" alt="'.$staffname.' picture" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$salary["amount"].'</td>
						<td>'.$salary["date_created"].'</td>
						<td>
							<a href="#" class="btn btn-success btn-xs edit_salary" id="'.$salary["id"].'"><i class = "fa fa-pencil"></i> Edit</a>
						</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="6"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}



	function search_staff_salary($id)
	{
		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT * from salary 
		inner join staffs 
		on `salary`.`staff_id` = `staffs`.`id` 
		where 
		salary.branch_id = :branch_id and (
		staffs.sname LIKE '%".$id."%' or 
		staffs.fname LIKE '%".$id."%' or 
		staffs.oname LIKE '%".$id."%' or 
		staffs.dob LIKE '%".$id."%' or 
		staffs.tel LIKE '%".$id."%' or 
		staffs.email LIKE '%".$id."%' or 
		salary.amount LIKE '%".$id."%' or 
		salary.date_created LIKE '%".$id."%')
		";

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $salary)
			{
				$staffname = $salary["sname"]." ".$salary["fname"]." ".$salary["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$salary["picture"].'" alt="'.$staffname.' picture" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$salary["amount"].'</td>
						<td>'.$salary["date_created"].'</td>
						<td>
							<a href="#" class="btn btn-success btn-xs edit_salary" id="'.$salary["id"].'"><i class = "fa fa-pencil"></i> Edit</a>
						</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="6"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}





	/////////////////////////DEBT SECTION/////////////////////
	function load_debt_table(){

		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT * from debt 
		inner join staffs 
		on `debt`.`staff_id` = `staffs`.`id` 
		where 
		debt.branch_id = :branch_id
		";

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $debt)
			{
				$staffname = $debt["sname"]." ".$debt["fname"]." ".$debt["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$debt["picture"].'" alt="'.$staffname.' picture" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$debt["amount"].'</td>
						<td>'.$debt["last_update_amount"].'</td>
						<td>'.$debt["last_update_date"].'</td>
						<td>
							<a href="#" class="btn btn-success btn-xs edit_debt" id="'.$debt["id"].'"><i class = "fa fa-pencil"></i> Edit</a>
						</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="7"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}

	function search_staff_debt($id)
	{
		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT * from debt 
		inner join staffs 
		on `debt`.`staff_id` = `staffs`.`id` 
		where 
		staffs.branch_id = :branch_id and (
		staffs.sname LIKE '%".$id."%' or 
		staffs.fname LIKE '%".$id."%' or 
		staffs.oname LIKE '%".$id."%' or 
		staffs.dob LIKE '%".$id."%' or 
		staffs.tel LIKE '%".$id."%' or 
		staffs.email LIKE '%".$id."%' or 
		debt.amount LIKE '%".$id."%' or 
		debt.last_update_amount LIKE '%".$id."%' or 
		debt.last_update_date LIKE '%".$id."%')
		";

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $debt)
			{
				$staffname = $debt["sname"]." ".$debt["fname"]." ".$debt["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$debt["picture"].'" alt="'.$staffname.' picture" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$debt["amount"].'</td>
						<td>'.$debt["last_update_amount"].'</td>
						<td>'.$debt["last_update_date"].'</td>
						<td>
							<a href="#" class="btn btn-success btn-xs edit_salary" id="'.$debt["id"].'"><i class = "fa fa-pencil"></i> Edit</a>
						</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="7"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}




	//////////PTF SECTION///////////////////////////
	function load_ptf_table(){
		$this->query = "
		SELECT * from ptf_mgt 
		where 
		id = 1
		";

		foreach ($this->query_result() as $ptf) {
			$type = $ptf['type'];
		    $value = $ptf['value'];
		    $date = $ptf['last_update_date'];
			$output = '
				<tr>
	              <td>';
	        $type === "perc"?$output.="Percentage":$output.="Cash";
	        $output.='
	        	  </td>
	              <td>';
	        $type === "perc"?$output.=$value."%":$output.=$value;
	        $output.='</td>
	              <td>'.$date.'</td>
	            </tr>
			';
		}

		
		return $output;
	}

	function fetch_ptf_amount($id){
		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);
		
		if($id == '0'){

			$this->query = "
			SELECT amount from ptf 
			where branch_id = :branch_id
			";

		}else{

			$this->query = "
			SELECT 
			ptf.amount as amount 
			from ptf 
			inner join staffs 
			on `ptf`.`staff_id` = `staffs`.`id` 
			where 
			ptf.branch_id = :branch_id 
			and (
			staffs.sname LIKE '%".$id."%' or 
			staffs.fname LIKE '%".$id."%' or 
			staffs.oname LIKE '%".$id."%' or 
			staffs.email LIKE '%".$id."%' or 
			ptf.amount LIKE '%".$id."%' or 
			ptf.month LIKE '%".$id."%' or 
			ptf.year LIKE '%".$id."%'
			)
			";
		}

		$amount = 0;

		foreach($this->query_result() as $ptf){
			$ptfamount = intval($ptf['amount']);

			$amount += $ptfamount;
		}

		return $amount;

	}

	function fetch_bonus_amount($id){
		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);
		
		if($id == '0'){

			$this->query = "
			SELECT amount from bonus 
			where branch_id = :branch_id
			";

		}else{

			$this->query = "
			SELECT 
			bonus.amount as amount 
			from bonus 
			inner join staffs 
			on `bonus`.`staff_id` = `staffs`.`id` 
			where 
			bonus.branch_id = :branch_id 
			and (
			staffs.sname LIKE '%".$id."%' or 
			staffs.fname LIKE '%".$id."%' or 
			staffs.oname LIKE '%".$id."%' or 
			staffs.email LIKE '%".$id."%' or 
			bonus.amount LIKE '%".$id."%' or 
			bonus.month LIKE '%".$id."%' or 
			bonus.year LIKE '%".$id."%'
			)
			";
		}

		$amount = 0;

		foreach($this->query_result() as $bonus){
			$bonusamount = intval($bonus['amount']);

			$amount += $bonusamount;
		}

		return $amount;

	}









	///////////STAFF PAYMENT SECTION //////////////////////////////////


	function fetch_staff_payment(){

		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT 
		staffs.sname as sname, 
		staffs.fname as fname, 
		staffs.oname as oname, 
		staffs.picture as picture, 
		salary_payment.total_paid as total_paid, 
		salary_payment.bonus as bonus, 
		salary_payment.ptf as ptf, 
		salary_payment.date_created as date_created, 
		salary_payment.id as id 
		from salary_payment 
		inner join staffs 
		on salary_payment.staff_id = staffs.id 
		where 
		staffs.branch_id = :branch_id 
		order by salary_payment.id desc 
		limit 10
		";

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $salary_pay)
			{
				$staffname = $salary_pay["sname"]." ".$salary_pay["fname"]." ".$salary_pay["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$salary_pay["picture"].'" alt="'.$staffname.' picture" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$salary_pay["total_paid"].'</td>
						<td>'.$salary_pay["bonus"].'</td>
						<td>'.$salary_pay["ptf"].'</td>
						<td>'.$salary_pay["date_created"].'</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="7"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}


	function fetch_req_staff_payment($id){

		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT 
		staffs.sname as sname, 
		staffs.fname as fname, 
		staffs.oname as oname, 
		staffs.picture as picture, 
		salary_payment.total_paid as total_paid, 
		salary_payment.bonus as bonus, 
		salary_payment.ptf as ptf, 
		salary_payment.date_created as date_created, 
		salary_payment.id as id 
		from salary_payment 
		inner join staffs 
		on salary_payment.staff_id = staffs.id 
		where 
		staffs.branch_id = :branch_id 
		and (
		staffs.sname LIKE '%".$id."%' or 
		staffs.fname LIKE '%".$id."%' or 
		staffs.oname LIKE '%".$id."%' or 
		staffs.dob LIKE '%".$id."%' or 
		staffs.tel LIKE '%".$id."%' or 
		staffs.email LIKE '%".$id."%' or 
		salary_payment.salary LIKE '%".$id."%' or 
		salary_payment.total_paid LIKE '%".$id."%' or 
		salary_payment.month LIKE '%".$id."%' or 
		salary_payment.year LIKE '%".$id."%' or 
		salary_payment.date_created LIKE '%".$id."%' or 
		salary_payment.bonus LIKE '%".$id."%' or 
		salary_payment.ptf LIKE '%".$id."%' or 
		salary_payment.debt LIKE '%".$id."%'
		)
		";

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $salary_pay)
			{
				$staffname = $salary_pay["sname"]." ".$salary_pay["fname"]." ".$salary_pay["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$salary_pay["picture"].'" alt="'.$staffname.' picture" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$salary_pay["total_paid"].'</td>
						<td>'.$salary_pay["bonus"].'</td>
						<td>'.$salary_pay["ptf"].'</td>
						<td>'.$salary_pay["date_created"].'</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="7"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}





	function fetch_all_ptfs(){

		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT * from ptf 
		inner join staffs 
		on `ptf`.`staff_id` = `staffs`.`id` 
		where ptf.branch_id = :branch_id 
		order by ptf.id desc 
		limit 6
		";

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $data)
			{
				$staffname = $data["sname"]." ".$data["fname"]." ".$data["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$data["picture"].'" alt="'.$staffname.' picture" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$data["email"].'</td>
						<td>'.$data["amount"].'</td>
						<td>'.$data["month"].'</td>
						<td>'.$data["year"].'</td>
						<td>'.$data["date_created"].'</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="8"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}


	function fetch_req_ptfs($id){

		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT * from ptf 
		inner join staffs 
		on `ptf`.`staff_id` = `staffs`.`id` 
		where 
		ptf.branch_id = :branch_id 
		and (
		staffs.sname LIKE '%".$id."%' or 
		staffs.fname LIKE '%".$id."%' or 
		staffs.oname LIKE '%".$id."%' or 
		staffs.email LIKE '%".$id."%' or 
		ptf.amount LIKE '%".$id."%' or 
		ptf.month LIKE '%".$id."%' or 
		ptf.year LIKE '%".$id."%'
		)
		";

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $data)
			{
				$staffname = $data["sname"]." ".$data["fname"]." ".$data["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$data["picture"].'" alt="'.$staffname.' picture" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$data["email"].'</td>
						<td>'.$data["amount"].'</td>
						<td>'.$data["month"].'</td>
						<td>'.$data["year"].'</td>
						<td>'.$data["date_created"].'</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="8"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}








	///////////////////// BONUS SECTION//////////////////////
	function fetch_all_bonus(){

		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT * from bonus 
		inner join staffs 
		on `bonus`.`staff_id` = `staffs`.`id` 
		where bonus.branch_id = :branch_id 
		order by bonus.id desc 
		limit 6
		";

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $data)
			{
				$staffname = $data["sname"]." ".$data["fname"]." ".$data["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$data["picture"].'" alt="'.$staffname.' picture" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$data["email"].'</td>
						<td>'.$data["amount"].'</td>
						<td>'.$data["month"].'</td>
						<td>'.$data["year"].'</td>
						<td>'.$data["date_created"].'</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="8"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}


	function fetch_req_bonus($id){

		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		$this->query = "
		SELECT * from bonus 
		inner join staffs 
		on `bonus`.`staff_id` = `staffs`.`id` 
		where 
		bonus.branch_id = :branch_id 
		and (
		staffs.sname LIKE '%".$id."%' or 
		staffs.fname LIKE '%".$id."%' or 
		staffs.oname LIKE '%".$id."%' or 
		staffs.email LIKE '%".$id."%' or 
		bonus.amount LIKE '%".$id."%' or 
		bonus.month LIKE '%".$id."%' or 
		bonus.year LIKE '%".$id."%'
		)
		";

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $data)
			{
				$staffname = $data["sname"]." ".$data["fname"]." ".$data["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$data["picture"].'" alt="'.$staffname.' picture" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$data["email"].'</td>
						<td>'.$data["amount"].'</td>
						<td>'.$data["month"].'</td>
						<td>'.$data["year"].'</td>
						<td>'.$data["date_created"].'</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="8"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}
	






	/////////////////////STOCKIN SECTION////////////////////////////

	

	function fetch_stocks($id=NULL, $status){
		$this->data = array(
			':id'		=>	$this->branch_id,
			':status'	=>	$status
		);


		if(empty($id)){
			$this->query = "
			SELECT * from stock 
			inner join stockin 
			on 
			stockin.stock_id = stock.id 
			where 
			stockin.branch_id = :id 
			and 
			stock.status = :status 
			order by stock.id desc 
			limit 20
			";
		}else{
			$this->query = "
			SELECT * from stock 
			inner join stockin 
			on 
			stockin.stock_id = stock.id 
			where 
			stockin.branch_id = :id 
			and 
			stock.status = :status 
			and (
			stock.name LIKE '%".$id."%' or 
			stock.date_created LIKE '%".$id."%'
			)";
		}

		$output = '';

		if($this->total_row() > 0){
			$i = 1;

			foreach($this->query_result() as $data)
			{
				$this->data = array(
					':prod_id'	=>	$data['prod_id']
				);

				$this->query = "
				SELECT * from product 
				where prod_id = :prod_id
				";

				$total_row = $this->total_row();

				$this->query = "
				SELECT sum(cost_price) as totalprice from product 
				where prod_id = :prod_id
				";

				foreach($this->query_result() as $costfetch){
					$cost = $costfetch['totalprice'];
				}

				$output.='
						<tr>
							<td>'.$i.'</td>
							<td><a href="#" data-id="'.$data["id"].'" class="view_products">'.$data["name"].'</a></td>
							<td>'.$total_row.'</td>
							<td>&#8358;'.$cost.'</td>
							<td>'.$data["date_created"].'</td>
							<td>';

				if($data['status']=='new') $output.='<label class="badge btn-xs btn-primary" id="newstock'.$data["id"].'">New</label>';

				if($data['status']=='conf') $output.='<label class="badge btn-xs btn-success" id="confstock'.$data["id"].'">Confirmed</label>';

				if($data['status']=='prob') $output.='<label class="badge btn-xs btn-warning" id="probstock'.$data["id"].'">Probated</label>';

				$output.='
							</td>
							<td>';
				if($data['status']=='new'){
					$output.='
								<button class="btn btn-success btn-xs stock_action" data-action="confirm" id="confstockbtn'.$data["id"].'" data-id="'.$data["id"].'">Confirm</button>
								<button class="btn btn-warning btn-xs stock_action" data-action="probate" id="probstockbtn'.$data["id"].'" data-id="'.$data["id"].'">Probate</button>
					';
				}else{
					if($data['status']=='conf') $output.='<button class="badge btn-success btn-xs">Confirmed</button>';
					if($data['status']=='prob') $output.='<button class="btn btn-success btn-xs stock_action" data-action="confirm" id="confstockbtn'.$data["id"].'" data-id="'.$data["id"].'">Confirm</button>';
				}
				$output.='
							</td>
						</tr>
				';
				$i++;
			}
		}else{
			$output.='
				<tr>
					<td colspan="8"><p class="text-center text-danger">No record found . . . !</p></td>
				</tr>
			';
		}

		
		return $output;
	}



	function fetch_stock_products($id){
		$this->data = array(
			':branch_id'	=>	$this->branch_id,
			':id'			=>	$id
		);

		$this->query = "
		SELECT * from stock 
		inner join stockin 
		on stock.id = stockin.stock_id 
		where 
		stockin.branch_id = :branch_id 
		and 
		stock.id = :id
		";

		$head = '';

		foreach ($this->query_result() as $value) {
			$head.='
				<table class="table table-bordered table-striped" style="width: 40%!important;">
			          <tr>
			            <th width="10%">Stock Name</th>
			            <td width="30%">'.$value["name"].'</td>
			          </tr>
			          <tr>
			            <th>Status</th>
			            <td>';
			    
			    if($value['status']=='new') $head.='<label class="badge btn-xs btn-primary">New</label>';

				if($value['status']=='conf') $head.='<label class="badge btn-xs btn-success">Confirmed</label>';

				if($value['status']=='prob') $head.='<label class="badge btn-xs btn-warning">Probated</label>';

			$head.='
						</td>
			          </tr>
			        </table>
			        <table id="datatable" class="table table-striped table-bordered">
			         <thead>
			          <tr>
			            <th>#ID</th>
			            <th>Product IMG</th>
			            <th>Product Name</th>
			            <th>Product Desc.</th>
			            <th>Category</th>
			            <th>Qty</th>
			            <th>Amount</th>
			            <th>Total</th>
			          </tr>
			        </thead>
			        <tbody>
			';
		}

		$body = '';

		$this->query = "
		SELECT * from (((product 
		inner join stockin 
		on stockin.prod_id = product.prod_id) 
		inner join stock 
		on stock.id = stockin.stock_id) 
		inner join category 
		on product.cat_id = category.cat_id) 
		where 
		stockin.branch_id = :branch_id 
		and 
		stock.id = :id
		";

		$i = 1;

		foreach($this->query_result() as $row){
			$body.='
				<tr>
		        	<td>'.$i.'</td>
					<td><img class="img-thumbnail" src="uploads/'.$row["prod_pic"].'" alt="'.$row["prod_name"].' picture" style="width: 50px; height:50px;"/></td>
		        	<td>'.$row["prod_name"].'</td>
		        	<td>'.$row["prod_desc"].'</td>
		        	<td>'.$row["cat_name"].'</td>
		        	<td>'.$row["prod_qty"].'</td>
		        	<td>&#8358;'.$row["cost_price"].'</td>
		        	<td>&#8358;'.($row["cost_price"]*$row["prod_qty"]).'</td>
		        </tr>
			';
			$i++;
		}

		$foot = '
		        </tbody>
		       </table>
		';

		$output = $head.$body.$foot;

		return $output;
	}











	///////////////////ASSIGNING NEW ROLE//////////////////////////////

	function fetch_roles(){
		$this->query = "
		SELECT * from roles
		";

		$output = '<option value="0"></option>';

		foreach ($this->query_result() as $role) {
			$output.='<option value="'.$role["role_id"].'">'.$role["role_name"].'</option>';
		}

		return $output;
	}

	function fetch_newrole($id=''){
		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		if(empty($id)){
			$this->query = "
			SELECT * from staffs 
			where 
			branch_id = :branch_id 
			order by id desc 
			limit 20
			";
		}else{
			$this->query = "
			SELECT * from staffs 
			where 
			branch_id = :branch_id 
			and (
			sname LIKE '%".$id."%' or 
			fname LIKE '%".$id."%' or 
			oname LIKE '%".$id."%' or 
			dob LIKE '%".$id."%' or 
			tel LIKE '%".$id."%' or 
			email LIKE '%".$id."%')
			";
		}

		$output = '';

		$i = 1;

		if($this->total_row() > 0){
			foreach($this->query_result() as $staff){
				$roles = $this->fetch_roles();
				$staffname = $staff["sname"]." ".$staff["fname"]." ".$staff["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$staff["picture"].'" alt="'.$staffname.'" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$staff["email"].'</td>
						<td>'.$staff["tel"].'</td>
						<td>
							<select class="form-control change_role" data-staff_id="'.$staff["id"].'" data-action="add">'.$roles.'</select>
						</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='<tr><td colspan="6" class="text-center text-danger">No record found . . . !</td></tr>';
		}

		return $output;
	}

	function fetch_staffrole($id=''){
		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		if(empty($id)){
			$this->query = "
			SELECT 
			staffs.sname as sname, 
			staffs.fname as fname, 
			staffs.oname as oname, 
			staffs.picture as picture, 
			staffs.email as email, 
			staffs.tel as tel, 
			roles.role_name as role_name, 
			staff_roles.id as id, 
			staff_roles.status as status
			from ((staffs 
			inner join staff_roles 
			on staff_roles.staff_id = staffs.id) 
			inner join roles 
			on roles.role_id = staff_roles.role_id) 
			where 
			staffs.branch_id = :branch_id 
			order by staff_roles.id desc 
			limit 20
			";
		}else{
			$this->query = "
			SELECT 
			staffs.sname as sname, 
			staffs.fname as fname, 
			staffs.oname as oname, 
			staffs.picture as picture, 
			staffs.email as email, 
			staffs.tel as tel, 
			roles.role_name as role_name, 
			staff_roles.id as id, 
			staff_roles.status as status 
			from ((staffs 
			inner join staff_roles 
			on staff_roles.staff_id = staffs.id) 
			inner join roles 
			on roles.role_id = staff_roles.role_id) 
			where 
			staffs.branch_id = :branch_id 
			and (
			staffs.sname LIKE '%".$id."%' or 
			staffs.fname LIKE '%".$id."%' or 
			staffs.oname LIKE '%".$id."%' or 
			staffs.dob LIKE '%".$id."%' or 
			staffs.tel LIKE '%".$id."%' or 
			staffs.email LIKE '%".$id."%' or 
			roles.role_name LIKE '%".$id."%' or 
			staff_roles.status = '".$id."'
			)
			";
		}

		$output = '';

		$i = 1;

		if($this->total_row() > 0){
			foreach($this->query_result() as $stafflogin){
				$staffname = $stafflogin["sname"]." ".$stafflogin["fname"]." ".$stafflogin["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$stafflogin["picture"].'" alt="'.$staffname.'" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$stafflogin["email"].'</td>
						<td>'.$stafflogin["tel"].'</td>
						<td>'.ucfirst($stafflogin["role_name"]).'</td>
						<td>';

				if($stafflogin["status"] == "active") $output.='<span class="badge btn-success" id="rolestatuslabel'.$stafflogin["id"].'">Active</span>';

				if($stafflogin["status"] == "inactive") $output.='<span class="badge btn-danger" id="rolestatuslabel'.$stafflogin["id"].'">Deactivated</span>';

				$output.='</td>
						<td>';

				if($stafflogin["status"] == "active") $output.='<button class="btn btn-sm btn-danger role_action" data-id="'.$stafflogin["id"].'" data-action="deactivate" id="roleactionbtn'.$stafflogin["id"].'">Deactivate</button>';

				if($stafflogin["status"] == "inactive") $output.='<button class="btn btn-sm btn-success role_action" data-id="'.$stafflogin["id"].'" data-action="activate" id="roleactionbtn'.$stafflogin["id"].'">Activate</button>';

				$output.='
						</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='<tr><td colspan="6" class="text-center text-danger">No record found . . . !</td></tr>';
		}

		return $output;
	}





	function fetch_stafflogin($id=''){
		$this->data = array(
			':branch_id'	=>	$this->branch_id
		);

		if(empty($id)){
			$this->query = "
			SELECT 
			staffs.sname as sname, 
			staffs.fname as fname, 
			staffs.oname as oname, 
			staffs.picture as picture, 
			staffs.email as email, 
			staffs.tel as tel, 
			user.user_id as id, 
			user.status as status
			from staffs 
			inner join user 
			on user.username = staffs.email 
			where 
			staffs.branch_id = :branch_id 
			order by user.user_id desc 
			limit 20
			";
		}else{
			$this->query = "
			SELECT 
			staffs.sname as sname, 
			staffs.fname as fname, 
			staffs.oname as oname, 
			staffs.picture as picture, 
			staffs.email as email, 
			staffs.tel as tel, 
			user.user_id as id, 
			user.status as status
			from staffs 
			inner join user 
			on user.username = staffs.email 
			where 
			staffs.branch_id = :branch_id 
			and (
			staffs.sname LIKE '%".$id."%' or 
			staffs.fname LIKE '%".$id."%' or 
			staffs.oname LIKE '%".$id."%' or 
			staffs.dob LIKE '%".$id."%' or 
			staffs.tel LIKE '%".$id."%' or 
			staffs.email LIKE '%".$id."%' or 
			user.status = '".$id."'
			)
			";
		}

		$output = '';

		$i = 1;

		if($this->total_row() > 0){
			foreach($this->query_result() as $stafflogin){
				$staffname = $stafflogin["sname"]." ".$stafflogin["fname"]." ".$stafflogin["oname"];
				$output.='
					<tr>
						<td>'.$i.'</td>
						<td><img src="uploads/'.$stafflogin["picture"].'" alt="'.$staffname.'" style="width: 50px; height:50px;"/></td>
						<td>'.$staffname.'</td>
						<td>'.$stafflogin["email"].'</td>
						<td>'.$stafflogin["tel"].'</td>
						<td>';

				if($stafflogin["status"] == "active") $output.='<span class="badge btn-success" id="loginstatuslabel'.$stafflogin["id"].'">Active</span>';

				if($stafflogin["status"] == "inactive") $output.='<span class="badge btn-danger" id="loginstatuslabel'.$stafflogin["id"].'">Deactivated</span>';

				$output.='</td>
						<td>';

				if($stafflogin["status"] == "active") $output.='<button class="btn btn-sm btn-danger login_action" data-id="'.$stafflogin["id"].'" data-action="deactivate" id="loginactionbtn'.$stafflogin["id"].'">Deactivate</button>';

				if($stafflogin["status"] == "inactive") $output.='<button class="btn btn-sm btn-success login_action" data-id="'.$stafflogin["id"].'" data-action="activate" id="loginactionbtn'.$stafflogin["id"].'">Activate</button>';

				$output.='
						</td>
					</tr>
				';
				$i++;
			}
		}else{
			$output.='<tr><td colspan="6" class="text-center text-danger">No record found . . . !</td></tr>';
		}

		return $output;
	}

	
}

?>