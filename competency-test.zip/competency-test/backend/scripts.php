<?php
    class Script extends PDO
    {
        public function register_user(){
            
        }
    }
?>