<?php 
    session_start(); 
    $page='Login';

    if(isset($_SESSION['test_user_id'])){
        header('location: ../dashboard');
    }
?>

<?php include('../controller/header.php'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <form id="login">
                    <div class="drop card">
                        <div class="card-header bg-primary">
                            <label>
                                <i class="fa fa-user"></i> User Login
                            </label>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="alert alert-success"></div>
                                <div class="alert alert-danger"></div>
                            </div>
                            <div class="form-group">
                                <label for="username">Username:</label>
                                <input type="text" name="username" id="username" required="required" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" name="password" id="password" required="required" class="form-control"/>
                            </div>
                        </div>
                        <div class="card-footer">
                            <input type="hidden" name="page" value="users" required="required" readonly="readonly"/>
                            <input type="hidden" name="action" value="login" required="required" readonly="readonly"/>
                            <button class="btn btn-outline-primary btn-sm btn-block" type="submit" id="login_btn">Login</button>
                            <div class="text-center">
                                <font size="2px">New User?</font> <a href="../register" role="button" class="btn-link text-warning">Register</a>
                            </div>
                        </div>
                    </div>
                </form>
                

            </div>
            <div class="col-md-4"></div>
        </div>
    </div>

<?php include('../controller/footer.php'); ?>
