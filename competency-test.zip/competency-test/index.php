<?php
    session_start();

    if(isset($_SESSION['test_user_id'])){
        header('location: weather_update');
    }else{
        header('location: login');
    }
?>