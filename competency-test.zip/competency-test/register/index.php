<?php $page='Register';?>
<?php include('../controller/header.php'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">


                <form id="register">
                    <div class="drop card">
                        <div class="card-header bg-primary">
                            <label>
                                <i class="fa fa-user-plus"></i> User Registration
                            </label>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="alert alert-success"></div>
                                <div class="alert alert-danger"></div>
                            </div>
                            <div class="form-group">
                                <label for="name">Name (In Full):</label>
                                <input type="text" name="name" id="name" required="required" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" name="email" id="email" required="required" class="form-control" data-parsley-type='email'/>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone:</label>
                                <input type="text" name="phone" id="phone" required="required" class="form-control" data-parsley-type='number'/>
                            </div>
                            <div class="form-group">
                                <label for="username">Username:</label>
                                <input type="text" name="username" id="username" required="required" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" name="password" id="password" required="required" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <label for="password">Confirm Password:</label>
                                <input 
                                    type="password" name="cpassword" 
                                    id="cpassword" required="required" 
                                    class="form-control"
                                    data-parsley-equalto="#password"
                                />
                            </div>
                        </div>
                        <div class="card-footer">
                            <input type="hidden" name="page" value="users" required="required" readonly="readonly"/>
                            <input type="hidden" name="action" value="register" required="required" readonly="readonly"/>
                            <button class="btn btn-outline-primary btn-sm btn-block" type="submit" id="reg_btn" name='reg_btn'>Register</button>
                            <div class="text-center">
                                <font size="2px">Already a user?</font> <a href="../login" role="button" class="btn-link text-warning">Login</a>
                            </div>
                        </div>
                    </div>
                </form>
                

            </div>
            <div class="col-md-2"></div>
        </div>
    </div>

<?php include('../controller/footer.php'); ?>
