$(function(){
    submitform(
        '#login', 'login.php', 
        '#login_btn', 'Login', isInput = false, 
        loc_reload=false, 'Login Successful', formreset=true, 
        redirect=true, redirect_loc='../weather_update'
    );///////////Login Handler

    submitform(
        '#register', 'register.php', 
        '#reg_btn', 'Register', isInput = false, 
        loc_reload=false, 'User Registered Successfully', formreset=true, 
        redirect=true, redirect_loc='../login'
    );///////////User Registration Handler


    var city = '';
    $('#submitWeather').click(function(){
        // alert('clicked');
        city = $('#city').val();
        if(city.trim() !== '')
        {
            $.ajax({
                url: 'https://api.openweathermap.org/data/2.5/weather?q='+city+'&units=metric&APPID=bcae46eae617dbfb49bee902cd563a52',
                type: 'GET',
                dataType:'json',
                beforeSend:function(){
                    $('#show').html('<div class="text-warning">Please wait while we process your request</div>');
                },
                success:function(data){
                    var widget = show(data);
                    $('#show').html(widget);
                    $('#city').val('');
                }
            })
        }else{
            $('.alert-danger').html('Field cannot be empty');
            $('.alert-danger').show();
        }
    });

    function show(data){
        return "<h3><strong>Weather ("+city+")</strong>: "+data.main.temp+"</h3>";
    }

    $('#logout').click(function(e){
        e.preventDefault();

        document.write(`
        <?php
            session_start();
            
            session_unset();

            session_destroy();
        ?>
        `);

        location.reload(true);
    })

})