/*
*
*
*
*
* AL-AMEEN main.js
*
*---------alert message manager
*---------shake modal function
*---------general form submission function
*---------upload file function
*---------button data submission function
*---------select input data submission function
*---------reset form function
*---------Picture upload manager
*---------format number input function
*---------reload page function
*---------replace char function
*---------get months function
*---------get Years function
*
*
*
*
*
*
*/





//////////////Alert Message Manager////////////////
$('.alert').hide();////////hide all alert messages with class pop

$(document).bind('input select change click', 'input select button .alert.pop', function(){
    $('.alert').hide();
})







///////////////Shake modal function////////////////////
function shakeModal(container) {
    $(container+' .modal-dialog').addClass('shake');
    $('input[type="password"]').val('');
    
    setTimeout(function() {
        $(container+' .modal-dialog').removeClass('shake');
    }, 1000);
}





////////////////////////General form Submission function////////////////////////

function submitform(
	container, ajax_location, 
	buttonname, buttonname_val, isInput = true, 
	loc_reload=false, successMsg, formreset=false, 
	redirect=false, redirect_loc=''
) {
    $(container).parsley();

    $(container).submit(function(e){
        e.preventDefault();

        if($(container).parsley().validate()){
            $.ajax({
                url:'../backend/codes/'+ajax_location,
                method:'post',
                data: $(this).serialize(),
                dataType: 'json',
                beforeSend:function(){
                    $(buttonname).attr('disabled','disabled');
                    if(isInput == true) $(buttonname).val('Initializing, please wait ~ ~ ~ !');
                    if(isInput == false) $(buttonname).html('Initializing, please wait ~ ~ ~ !');
                },
                success:function(data){

                    $(buttonname).attr('disabled',false);

                    if(isInput == true) $(buttonname).val(buttonname_val);
                    if(isInput == false) $(buttonname).html(buttonname_val);


                    if(data.error){
                        $('.alert-danger').html(data.error);
                        $('.alert-danger').show();
                        
                    }else{
                        $('.alert-success').text(successMsg);
                        $('.alert-success').show();

                        if(redirect === true){
                            window.location = redirect_loc;
                        }
                        
                        if(loc_reload == true){
                            location.reload(true);
                        }

                        if(formreset == true){
                        	resetForm(container);
                        }

                        

                    }
                }
            })
        }
    });
}





////////////////////////Upload file function///////////////////////////
function upload_file(url) {
    
    $('#picture_form').submit(function(e){
        e.preventDefault();

        if($('#picture_form').parsley().validate()){
            $.ajax({
                url:url,
                method:'post',
                data: new FormData(this),
                processData:false,
                cache:false,
                contentType:false,
                success:function(data){
                    $('#pic_name').val(data);
                }
            })
        }
    });
}




////////////////button data submission/////////////////////////////
function submit_btnData(
    btn_name, btn_ref, location, 
    disabledBtn = true, returnText = false, btnText = '', 
    changeAction = false, newAction='', 
    changeClass = false, orig_class = '', new_class=''
){
    $(document).on('click', btn_name, function(){
        var action = $(this).attr('data-action');
        var id = $(this).attr('data-id');


        $.ajax({
            url:'../ajax_actions/'+location,
            method:'post',
            data:{action: action, id:id},
            dataType:'json',
            beforeSend:function(){
                console.log('Sending Request\nAction: '+action+'\nID: '+id);
            },
            success:function(data){
                console.log('Request sent');
                if(data.success){
                    alert('Status changed');
                }else{
                    alert(data.error);
                }

                // reload();
                if(disabledBtn == true) $(btn_ref+id).attr('disabled','disabled');
                if(returnText == false) $(btn_ref+id).text($(btn_ref+id).attr('title')+'d');
                if(returnText == true) $(btn_ref+id).html(btnText);

                if(changeAction == true) $(btn_ref+id).attr('data-action', newAction);

                if(changeClass == true){
                    $(btn_ref+id).removeClass(orig_class);
                    $(btn_ref+id).addClass(new_class);
                }
            }
        })
    })
}





////////////////SELECT input data submission/////////////////////////////
function submit_selectData(
    input_name, location, reload = false, 
    sendData = true, dataRef='', acceptEmpty = false
){
    $(document).on('change', input_name, function(){
        var action = $(this).attr('data-action');
        var id = $(this).attr('data-id');
        
        var val = $(this).val();

        if(acceptEmpty == false && val == 0){
            alert('Selected value cannot be empty . . . !');
        }else{
            $.ajax({
                url:'../ajax_actions/'+location,
                method:'post',
                data:{action:action, id:id, val:val},
                dataType:'json',
                beforeSend:function(){
                    console.log('Sending Request\nAction: '+action+'\nID: '+id);
                },
                success:function(data){
                    console.log('Request sent');
                    if(data.success){
                        alert(data.successMsg);

                        if(reload == true) reload();

                        if(sendData == true){
                            $(dataRef+id).html(data.text);
                        }
                    }else{
                        alert(data.error);
                    }
                }
            });
        }
    });
}




///////////////////reset form function///////////////////////
function resetForm(container) {
	$(container)[0].reset();
	$(container).parsley().reset();
}






////////////Picture upload manager////////////////////////////////////
$(document).ready(function(){
    $('#pic_view').attr('src', '../images/'+$('#pic_name').val()); 

    // $(document).on('input', '#pic_name', function(){
    // })

    setInterval(function(){
        $('#pic_view').attr('src', '../images/'+$('#pic_name').val());
    },1000);


    //// upload picture  ----- triggers submit picture form button
    $('#picture').change(function(){
        $('#picture_button').click();
    })
})








///////////////////////////format number input function //////////////////////////////

function format_number(number, container){

    number = String(number);
    
    for(var i = 1; i <= 10; i++)
    {
        number = number.replace(',','');
    }
    
    if(number.substr(0,1) == '0' && number.length > 1 && number.substr(1,1) != '.'){
        number = number.substr(1,number.length);
    }

    realnum = number;
    // alert(number);

    

    var count = 3;


    if(number.trim().length == 0){
        number = 0;
    }

    if(number.length > 0 && number.length < 4){
        number = number;
    }

    else if(number.length >= 4 && number.length < 7){
        number = number.substr(0,number.length - count) + ',' + number.substr(number.length - count,count);
    }

    else if(number.length >= 7 && number.length < 10){
        number = number.substr(0,number.length - (2*count)) + ',' + number.substr(number.length - (2*count),count) + ',' + number.substr(number.length - count,count);
    }

    else if(number.length >= 10 && number.length < 13){
        number = number.substr(0,number.length - (3*count)) + ',' + number.substr(number.length - (3*count),count) + ',' + number.substr(number.length - (2*count),count) + ',' + number.substr(number.length - count,count);
    }

    else if(number.length >= 13 && number.length < 16){
        number = number.substr(0,number.length - (4*count)) + ',' + number.substr(number.length - (4*count),count) + ',' + number.substr(number.length - (3*count),count) + ',' + number.substr(number.length - (2*count),count) + ',' + number.substr(number.length - count,count);
    }


    else if(number.length >= 16 && number.length < 19){
        number = number.substr(0,number.length - (5*count)) + ',' + number.substr(number.length - (5*count),count) + ',' + number.substr(number.length - (4*count),count) + ',' + number.substr(number.length - (3*count),count) + ',' + number.substr(number.length - (2*count),count) + ',' + number.substr(number.length - count,count);
    }

    $(container).val(number);
    
    return realnum;
}





////////////////Reload page function////////////////////
function reload(){
    location.reload(true);
}



////////////////replace char function////////////////////

function replace_char(container, char){
    var num = $(container).val();

    for(var i=1; i<=5; i++){
        num = Number(String(num).replace(char, ''));
    }

    return num;
}


////////////////get months function////////////////////

function getMonths(container){
    var month = ['January','February', 'March','April','May','June','July','August','September','October','November','December'];
    var output = '<option value="">Select . . . </option>';
    for(var i = 0; i<=11; i++){
        output +='<option>'+month[i]+'</option>';
    }

    $(container).html(output);
}



////////////////Get years function////////////////////

function getYears(container){
    var currentYear = new Date().getFullYear();
    var output = '<option value="">Select . . . </option><option>'+currentYear+'</option>';

    for(var i = 1; i<=5; i++){
        output +='<option>'+(currentYear - i)+'</option>';
    }

    $(container).html(output);
}




