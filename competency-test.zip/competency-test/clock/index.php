<?php $page='Register'; $ref='c';?>
<?php include('../controller/header.php'); ?>
<?php include('../controller/header2.php'); ?>




<br/><br/>
<div class="container">
	<div class="row">
		<div class="col-md-6">
			<div class="text-center">
				<div id="myclock"></div>
				<div id="alarm1" class="alarm">
					<a href="javascript:void(0)" role="button" class="btn btn-primary btn-xs" id="turnOffAlarm">ALARM OFF</a>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					ALARM FUNCTIONS
				</div>
				<div class="card-body">
					<div class="form-group">
						<label class="font-weight-bold">Manual Alarm</label>
						<input type="text" id="altime" placeholder="hh:mm" class="form-control"/> <br>
						<a href="javascript:void(0)" role="button" class="btn btn-xs btn-outline-success btn-flat" id="set">Set Alarm</a>
					</div>
					<div class="form-group">
						
						<label class="font-weight-bold">Automatic Alarm</label>
						<button class="btn btn-outline-primary btn-xs btn-flat btn-block" id="get_sunrise">Set Sunrise Alarm</button>
						<button class="btn btn-outline-primary btn-xs btn-flat btn-block" id="get_sunset">Set Sunset Alarm</button>
					</div>
				</div>
			</div>
		</div>
	</div><br><br><br><br>
</div>
<!-- <link rel="stylesheet" href="css/main.css"> -->
<script language="javascript" type="text/javascript" src="js/jquery.thooClock.js"></script>  
<script language="javascript">
	var intVal, myclock;

	$(window).resize(function(){
		window.location.reload();
	});

	$(document).ready(function(){
		$('#alarm1').hide();
		var audioElement = new Audio("");

		//clock plugin constructor
		$('#myclock').thooClock({
			size:$(document).height()/1.4,
			sweepingMinutes:true,
			sweepingSeconds:true,
			onAlarm:function(){
				//all that happens onAlarm
				$('#alarm1').show();
				alarmBackground(0);
				//audio element just for alarm sound
				document.body.appendChild(audioElement);
				var canPlayType = audioElement.canPlayType("audio/ogg");
				if(canPlayType.match(/maybe|probably/i)) {
					audioElement.src = 'alarm.ogg';
				} else {
					audioElement.src = 'alarm.mp3';
				}
				// erst abspielen wenn genug vom mp3 geladen wurde
				audioElement.addEventListener('canplay', function() {
					audioElement.loop = true;
					audioElement.play();
				}, false);
			},
			showNumerals:true,
			brandText:'CloudWare',
			brandText2:'Technologies',
			onEverySecond:function(){
				//callback that should be fired every second
				//console.log(new Date().getSeconds());
			},
			// alarmTime:'15:30',
			offAlarm:function(){
				$('#alarm1').hide();
				audioElement.pause();
				clearTimeout(intVal);
				$('body').css('background-color','#FCFCFC');
			}
		});

	});



	$('#turnOffAlarm').click(function(){
		$.fn.thooClock.clearAlarm();
	});


	$('#set').click(function(){
		var inp = $('#altime').val();
		if(inp.trim() !== ''){
			$.fn.thooClock.setAlarm(inp);
		}else{
			alert('Please enter alarm to set . . . !')
		}
	});

	
	function alarmBackground(y){
			var color;
			if(y===1){
				color = '#CC0000';
				y=0;
			}
			else{
				color = '#FCFCFC';
				y+=1;
			}
			$('body').css('background-color',color);
			intVal = setTimeout(function(){alarmBackground(y);},100);
	}


	function get_sunset_time(){
		return "<?=date_sunset(time(), SUNFUNCS_RET_STRING, 38.4, -9, 90, 1);?>";
	}
	function get_sunrise_time(){
		return "<?=date_sunrise(time(), SUNFUNCS_RET_STRING, 38.4, -9, 90, 1);?>";
	}

	$('#get_sunrise').click(function(){
		var time = get_sunrise_time();
		$.fn.thooClock.setAlarm(time);
		alert('Sunrise Time Set');
	})

	$('#get_sunset').click(function(){
		var time = get_sunset_time();
		$.fn.thooClock.setAlarm(time);
		alert('Sunset Time  Set');
	})
</script>
<?php include('../controller/footer.php'); ?>
