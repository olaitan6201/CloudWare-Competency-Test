<?php

    if(isset($_POST['page']))
    {
        if($_POST['page'] == 'Get_Time')
        {
            if($_POST['action'] == 'sunrise'){
                $time = date_sunrise(time(), SUNFUNCS_RET_STRING, 38.4, -9, 90, 1);

                $output = array(
                    'time'  =>  String($time)
                );

                echo json_encode($output);
            }

            if($_POST['action'] == 'sunet'){
                $time = date_sunset(time(), SUNFUNCS_RET_STRING, 38.4, -9, 90, 1);

                $output = array(
                    'time'  =>  String($time)
                );

                echo json_encode($output);
            }
        }
    }
?>