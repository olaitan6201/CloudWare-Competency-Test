<?php $page='Register'; $ref='w';?>
<?php include('../controller/header.php'); ?>
<?php include('../controller/header2.php'); ?>

    <div class="container">
        <div class="row form-group">
            <div class="alert-danger"></div>
        </div>
        <div class="row form-group">
            <label for="city">Enter your city name:</label>
            <input type="text" name="city" id="city" class="form-control"/>
        </div>
        <div class="row form-group">
            <button id="submitWeather" class="btn btn-primary">Search City</button>
        </div>
        <div class="row form-group">
            <div id="show"></div>
        </div>
    </div>

<?php include('../controller/footer.php'); ?>
