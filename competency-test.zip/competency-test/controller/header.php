<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$page?></title>


    <link rel="stylesheet" href="../assets/bootstrap/dist/css/bootstrap.css">
    <script src="../assets/jquery/jquery.min.js"></script>
    <script src="../assets/popper/popper.min.js"></script>
    <script src="../assets/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../assets/parsley/dist/parsley.js"></script>

    <link rel="stylesheet" href="../assets/summernote/summernote.css"/>
    <script src="../assets/summernote/summernote.js"></script>

    <link rel="stylesheet" type="text/css" href="../assets/font-awesome/css/all.css"/>
    <link rel="stylesheet" type="text/css" href="../assets/css/parsley_style.css"/>
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css"/>

</head>
<body>