<?php
session_start();
  if(!isset($_SESSION['test_user_id'])){
    header('location: ../login');
  }
?>
<nav class="navbar navbar-expand navbar-dark bg-primary fixed-top">
  <a class="navbar-brand" href="#"><b>CloudWare Technologies (Competency Test)</b></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">

      <li class="nav-item <?php echo $ref==='w'?'active':'';?>">
        <a class="nav-link" href="../weather_update">
          Weather Update
        </a>
      </li>

      <li class="nav-item <?php echo $ref==='b'?'active':'';?>">
        <a class="nav-link" href="../bank_transfer">
          Bank Transfer
        </a>
      </li>

      <li class="nav-item <?php echo $ref==='c'?'active':'';?>">
        <a class="nav-link" href="../clock">
          Clock/Alarm
        </a>
      </li>

    </ul>
    <div class="form-inline my-2 my-lg-0">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="../logout.php" role="button">
                    <i class="fas fa-forward"></i> Log Out
                </a>
            </li>
        </ul>
    </div>
</nav>
<br><br><br>