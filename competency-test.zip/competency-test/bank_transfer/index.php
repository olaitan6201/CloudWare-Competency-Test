<?php $page='Register'; $ref='b';?>
<?php include('../controller/header.php'); ?>
<?php include('../controller/header2.php'); ?>
    <?php date_default_timezone_set('Africa/Lagos'); ?>
    <div class="container-fluid transfer_form">
        <form method="post">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <label class="font-weight-bold">Bank Transer</label>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="send_name">Sender's Name</label>
                                <input type="text" name="send_name" class="form-control" required="required"/>
                            </div>
                            <div class="form-group">
                                <label for="send_acct">Sender's Account Number</label>
                                <input type="text" name="send_acct" class="form-control" required="required"/>
                            </div>
                            <div class="form-group">
                                <label for="rec_name">Reciever's Name</label>
                                <input type="text" name="rec_name" class="form-control" required="required"/>
                            </div>
                            <div class="form-group">
                                <label for="rec_acct">Reciever's Account Number</label>
                                <input type="text" name="rec_acct" class="form-control" required="required"/>
                            </div>
                            <div class="form-group">
                                <label for="transtype">Transer Type</label>
                                <select name="transtype" id="transtype" class="form-control" required="required">
                                    <option>Intrabank</option>
                                    <option>Interbank</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="amount">Amount in <span id="amt_type">&#8358;</span></label>
                                <input type="number" name="amount" class="form-control" required="required"/>
                            </div>
                            <div class="form-group">
                                <input type="submit" name="transfer" class="btn btn-outline-primary btn-flat btn-block" value="Transfer"/>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
        </form><br><br><br>
    </div>
<?php
    extract($_POST);
    if(isset($transfer)){
?>
    <script>
        $(function(){
            $('.transfer_form').html('');
        })
    </script>
    <div class="container transfer-message">
        <table class="table table-bordered">
            <tbody>
                <tr>
                    <th>Transaction ID: </th>
                    <td><?=uniqid();?></td>
                </tr>
                <tr>
                    <th>Transaction Date: </th>
                    <td><?=date('d-m-Y ; h:i:s');?></td>
                </tr>
                <tr>
                    <th>Transaction Type: </th>
                    <td><?=$transtype;?></td>
                </tr>
                <tr>
                    <th>Transaction Response: </th>
                    <td><span class="badge bg-warning">Processing...</span></td>
                </tr>
                <tr>
                    <th>Sender's Name: </th>
                    <td><?=$send_name;?></td>
                </tr>
                <tr>
                    <th>Sender's Acct. Number: </th>
                    <td><?=$send_acct;?></td>
                </tr>
                <tr>
                    <th>Reciever's Name: </th>
                    <td><?=$rec_name;?></td>
                </tr>
                <tr>
                    <th>Reciever's Acct. Number: </th>
                    <td><?=$rec_acct;?></td>
                </tr>
                <tr>
                    <th>Amount Transferred: </th>
                    <td><?=$transtype=='Intrabank'?'&#8358;':'$';?><?=$amount;?></td>
                </tr>
            </tbody>
        </table>
        <div class="center">
            <a href="javascript:print();" role="button" class="btn btn-primary btn-sm btn-flat">
                <i class="fa fa-print"></i> Print
            </a>
        </div>
    </div>
<?php
    }
?>
<script>
    $(function(){
        $('#transtype').change(function(){
            if($(this).val() == 'Intrabank'){
                $('#amt_type').html('&#8358;');
            }else{
                $('#amt_type').text('$');
            }
        })
    })
</script>

<?php include('../controller/footer.php'); ?>
