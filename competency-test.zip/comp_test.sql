-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2021 at 08:45 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `comp_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `trans_pin` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `phone`, `password`, `trans_pin`) VALUES
(1, 'Olaitan Habeeb', 'olamide', 'olaitan6201@gmail.com', '07080977816', '$2y$10$smTs.odY22m4Ef4qlyp.xOV6zKXugWOdYM4Rgejppxl0yndTToEhK', 0),
(2, 'Olaitan Habeeb', 'habeeb', 'olaitan@yahoo.com', '07080977816', '$2y$10$eIiHk4EQGo75yYOAlKxpfO4imxJeyBF0Jno5iOPYxnpR2jvdMsFlO', 0),
(3, 'Olaitan Olamide', 'olaitan', 'olaitan6201@gmail.com', '07080977816', '$2y$10$x0PZdBDcR2sLhhdaAe8sG.udwj/4b/MwbM8FSB0FKDSKkRS3ZJN7G', 0),
(4, 'Olaitan Habeeb', 'olaitan122', 'olaitan6201@gmail.com', '07080977816', '$2y$10$c7xtvc4OFxBxnDLS32EO.O8drYsRDuC94RY91T/feUHzXsWfBKPwi', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
